<?php $__env->startSection('content'); ?>

    <section><!--form-->
        <div class="container">
            <div style="margin-left: 0px;">
                <img src="<?php echo e(asset('image/default.png')); ?>" height="200px" width="200px">
                
                <p style="margin-top: 20px;">Name :<strong><?php echo e(Session::get('customer_name')); ?></strong> </p><br>
                <p>Email : <strong><?php echo e(Session::get('customer_email')); ?></strong></p><br>
                <p>Phone Number : <strong><?php echo e(Session::get('mobile_number')); ?></strong></p><br>
                
            </div>
        </div>
    </section><!--/form-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>