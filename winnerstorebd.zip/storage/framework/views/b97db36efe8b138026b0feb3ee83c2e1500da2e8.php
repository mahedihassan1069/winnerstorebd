<?php $__env->startSection('content'); ?>

    <section><!--form-->
        <div class="container">
            <div style="margin-left: 0px;">
                <img src="<?php echo e(asset('image/default.png')); ?>" height="200px" width="200px">
                <p style="margin-top: 20px;">Name : </p><br>
                <p>Email : <strong></strong></p><br>
                <p>Your purchase description : <strong></strong></p><br>
                <div class="container">
                    <table class="table">
                        <thead>
                        <tr>
                            <th>#</th>
                            <th>Product Name</th>
                            <th>Price</th>
                        </tr>
                        </thead>
                        <tbody>
                        <tr>
                            <th scope="row">1</th>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th scope="row">2</th>
                            <td></td>
                            <td></td>
                        </tr>
                        <tr>
                            <th scope="row">3</th>
                            <td></td>
                            <td></td>
                        </tr>
                        </tbody>
                    </table>
                </div>

            </div>
        </div>
    </section><!--/form-->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>